package application.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class Controller implements Initializable, Runnable{

	   @FXML
	    private TextField from;

	    @FXML
	    private TextField to;
	    
	    @FXML
	    private TextField object;

	    @FXML
	    private TextArea message;

	    @FXML
	    private Button infos;

	    @FXML
	    private ImageView send_icon;

	    
	    public void run () {
	    	String pwd = JOptionPane.showInputDialog(null, "Mot de passe de votre compte : ");
	    	
	    	if ( !from.getText().isEmpty() && !to.getText().isEmpty() && !object.getText().isEmpty() &&
	    			!message.getText().isEmpty() ) {
	    		
	    		if ( !pwd.isEmpty() ) {
		    		
		    		send_icon.setVisible(true);
			    	TranslateTransition tt = new TranslateTransition( Duration.seconds(8) ,send_icon);
			    	tt.setFromX(0);
			    	tt.setToX(400);
			    
			    	tt.setAutoReverse(false);
			    	
			    	tt.play();
			    	
			    	tt.setOnFinished( event -> {
			    		send_icon.setVisible(false);
			    		SendMail.send(from.getText(), pwd,to.getText(), object.getText(), message.getText());
			    		clear();
			    		
			    	});
		    	} else {
		    		JOptionPane.showMessageDialog(null, "Entr�e votre mot de passe !!!");
		    	}
	    			
	    	} else {
	    		JOptionPane.showMessageDialog(null, "Remplissez tout les champs");
	    	}
	    
	    }
	    @FXML
	    void send(ActionEvent event) {
	     	Thread t = new Thread(this);
    		t.start();
	    }

	    public void clear () {
	    	from.clear();
	    	to.clear();
	    	object.clear();
	    	message.clear();
	    }
	    
	    @FXML
	    void infos ( ActionEvent event ) {
	    	JOptionPane.showMessageDialog(null, "Pour envoy� un email "
	    			+ "depuis un adresse, configurer le \n "
	    			+ "param�tre de s�curit� de votre compte gmail.\n"
	    			+ "Vous pouvez envoyer un mail � plusieur\n "
	    			+ "destinataire en s�parant  les adresses email"
	    			+ " \npar un virgule.");
	    }

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
		}
	    
	    
	    

}
